# Online-Auction-App
  An Online Auction Platform built with the MERN stack (MongoDB, Express.js, React, Node.js) that allows users to create, bid on, and manage auctions in real time. It features JWT authentication, real-time bidding with Socket.io, payment integration and an admin dashboard for managing users and auctions. 
